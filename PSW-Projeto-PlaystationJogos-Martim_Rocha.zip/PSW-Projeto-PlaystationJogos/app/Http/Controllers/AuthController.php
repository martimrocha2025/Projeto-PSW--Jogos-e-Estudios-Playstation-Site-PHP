<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class AuthController extends Controller
{
    public function AddUser(Request $request){

        return view('users.addusers');
    }

    public function StoreUser(Request $request){

//dd($request-> all());
$request->validate([
'name' => 'required|max:50|string',
'email' => 'required|unique:users,email|email',
'password' =>'required|min:8'
]);

//inserir os dados na bd
User::insert([
    'name' => $request->name,
    'email' => $request->email,
    'password' => Hash::make($request->password),
    
]);

return redirect()->route('homepage')->with('message', 'User adicionado com sucesso!');
}

}