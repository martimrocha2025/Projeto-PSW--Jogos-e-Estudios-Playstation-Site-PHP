<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;  
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Hash;

class EstudioController extends Controller
{
    
public function Estudios(){
    
$estudioFromDB = $this->GetEstudioFromDB();

return view('estudios.verEstudio', compact('estudioFromDB'));
}

public function AddEstudio(){

return view('estudios.addEstudio');
}


private function GetEstudioFromDB(){

$estudioFromDB = DB::table('estudios')->get();

return $estudioFromDB;
}


public function StoreEstudio(Request $request){

$request->validate([
    'name_estudio' => 'required|string|max:255',
    'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
]);
DB::table('estudios')->insert([
    
    'name_estudio' => $request->name_estudio,
    'logo' => $request->hasFile('logo') ? Storage::putFile('images', $request->file('logo')) : null,
]);

return redirect()->route('estudios.home')->with('message','Estúdio adicionado com sucesso!');
}


public function UpdateEstudio(Request $request, $id){

$estudio = DB::table('estudios')
->where('id', $id)
->first();

if (! $estudio) {
    abort(404);
}

return view('estudios.updateEstudio', compact('estudio'));

}

public function PutEstudio(Request $request, $id){

$request->validate([
    'name_estudio' =>'required|string|max:255',
]);


if ($request->hasFile('logo')) {
    $logo = Storage::putFile('images', $request->logo);
}

DB::table('estudios')
    ->where('id', $id)
    ->update([
        'name_estudio' => $request->name_estudio,
        'logo' => $request->hasFile('logo') ? Storage::disk('public')->putFile('images', $request->file('logo')) : null,
    ]);

return redirect()->route('estudios.home')->with('message','Estúdio atualizado com sucesso');
}

public function DeleteEstudio($id){

DB::table('jogos')
->where('estudio_id', $id)
->delete();

DB::table('estudios')
->where('id', $id)
->delete();

return back();
}

}
