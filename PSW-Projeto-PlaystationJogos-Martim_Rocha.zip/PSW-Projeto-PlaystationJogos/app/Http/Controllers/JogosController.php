<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class JogosController extends Controller
{
    public function VerJogos($id){   
    $Jogos = DB::table('jogos')
    ->where('estudio_id', $id)
    ->get();

return view('jogos.verjogos', compact('Jogos'));
}

public function AddJogo(){
    
$estudios = DB::table('estudios')
->select('id', 'name_estudio')
->get();

return view('jogos.addJogos', compact('estudios'));

}

public function StoreJogo(Request $request){

$request->validate([
    'name' => 'required|string|max:255',
    'data_lancamento' => 'required|date',
    'estudio_id' => 'required|exists:estudios,id',
]);

DB::table('jogos')->insert([
    'name' => $request->name,
    'genre' => $request->genre,
    'date' => $request->data_lancamento,
    'image' => $request->hasFile('image') ? Storage::putFile('images', $request->file('image')) : null,
    'estudio_id' => $request->estudio_id,
]);

return redirect()->route('jogos.verjogos', ['id' => $request->estudio_id])->with('message','Jogo adicionado com sucesso!');
}


public function UpdateJogo(Request $request, $id){

$jogo = DB::table('jogos')
->where('id', $id)
->first();

$estudios = DB::table('estudios')
->select('id', 'name_estudio')
->get();

return view('jogos.updateJogos', compact('jogo', 'estudios'));
}

public function PutJogo(Request $request, $id){
$request->validate([
    'name' => 'required|string|max:255',
    'data_lancamento' => 'required|date',
    'estudio_id' => 'required|exists:estudios,id',
]);

$image = null;

if ($request->hasFile('image')) {
    $image = Storage::putFile('images', $request->file('image'));
}

DB::table('jogos')
    ->where('id', $id)
    ->update([
    'name' => $request->name,
    'date' => $request->data_lancamento,
    'estudio_id' => $request->estudio_id,]);

return redirect()->route('jogos.verjogos', ['id' => $request->estudio_id])->with('message', 'Jogo atualizado com sucesso!');
}

public function DeleteJogo($id){
    DB::table('jogos')
    ->where('id', $id)
    ->delete();

    return back();
}
}
