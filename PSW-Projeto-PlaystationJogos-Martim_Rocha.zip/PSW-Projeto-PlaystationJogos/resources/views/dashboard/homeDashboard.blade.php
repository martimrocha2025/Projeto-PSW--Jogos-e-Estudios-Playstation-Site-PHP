@extends ('layout.fo')

@section('content')

<h2>Dashboard</h2>
<p>Olá, {{Auth::user()->name}}</p>
@if(Auth::user()->user_type == \App\Models\User::USER_ADMIN)
    <p>És Admin</p>
@else
    <p>És User</p>
@endif

@endsection