@extends ('layout.fo')


@section('content')

@auth
@if (Auth::user()->user_type == \App\Models\User::USER_ADMIN)
<h2>Adicionar Estúdio</h2>

<form method="POST" action="{{ route('estudios.store') }}" enctype="multipart/form-data">
    @csrf
  <div class="mb-3">
    <label for="name_estudio" class="form-label">Nome</label>
    <input type="text" name="name_estudio" class="form-control" id="name_estudio" aria-describedby="nameHelp">
    <div id="nameHelp" class="form-text">Inserir o nome do estúdio.</div>
  </div>
  @error('name')
  <p> Nome inválido </p>
  @enderror
  <div class="mb-3">
    <label for="logo" class="form-label">Logo do Estúdio</label>
    <input type="file" accept="image/*" name="logo" class="form-control" id="logo">
  </div>
  @error('logo')
<p> Imagem não suportada </p>
  @enderror
  <button type="submit" class="btn btn-primary">Adicionar Estúdio</button>
</form>

@else
    <h2>Não tens permissão para aceder a esta página</h2>
@endif
@endauth
@endsection