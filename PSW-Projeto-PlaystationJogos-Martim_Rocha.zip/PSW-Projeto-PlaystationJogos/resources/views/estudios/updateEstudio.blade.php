@extends ('layout.fo')


@section('content')

@auth
@if (Auth::user()->user_type == \App\Models\User::USER_ADMIN)
@isset($estudio)
<h2>Editar Estúdio</h2>
<form method="POST" action="{{ route('estudios.put', $estudio->id) }}" enctype="multipart/form-data">
@method('PUT')    
@csrf
  <div class="mb-3">
    <label for="name_estudio" class="form-label">Nome</label>
    <input type="text" name="name_estudio" value="{{ old('name_estudio', $estudio->name_estudio) }}" class="form-control" id="name_estudio" aria-describedby="nameHelp">
    <div id="nameHelp" class="form-text">Inserir o nome do estúdio.</div>
  </div>
  @error('name_estudio')
  <p> Nome inválido </p>
  @enderror
  <div class="mb-3">
    <label for="logo" class="form-label">Logo do Estúdio</label>
    <input type="file" accept="image/*" name="logo" class="form-control" id="logo">
  </div>
  @error('logo')
<p> Imagem não suportada </p>
    @enderror
  <button type="submit" class="btn btn-primary">Atualizar Estúdio</button>
</form>

@else
    <h2>Não tens permissão para aceder a esta página</h2>
@endif
@endisset
@endauth
@endsection