@extends ('layout.fo')

@section('content')

<h2> Estúdios Playstation </h2>
<table class="table table-primary">
<thead>
    <tr>
        <th>Logo</th>
        <th>Nome</th>
        <th></th>
    </tr>
</thead>  
<tbody>
    @foreach ($estudioFromDB as $estudio)
    <tr>
<td><img width="40px" height= "40px" src="{{$estudio->logo ? asset('storage/' . str_replace('public/', '', $estudio->logo)) : asset('images/nophoto.jpg')}}" alt=""> </td>
<td>{{ $estudio->name_estudio }}</td>
<td><a href="{{ route('jogos.verjogos', ['id' => $estudio->id]) }}" class="btn btn-info">Ver Jogos</a> 
@auth
@if (Auth::user()->user_type == \App\Models\User::USER_ADMIN)    
<a href="{{ route('estudios.delete', $estudio->id) }}" class="btn btn-danger">Eliminar</a>
    <a href="{{ route('estudios.update', $estudio->id) }}" class="btn btn-warning">Editar</a>
@endif
@endauth
</td>

    </tr>
    @endforeach
  </tbody>
</table>
@auth
@if (Auth::user()->user_type == \App\Models\User::USER_ADMIN)
<a href="{{ route('estudios.add') }}" class="btn btn-primary">Adicionar Estúdio</a>
@endif
@endauth

@endsection