@extends ('layout.fo')


@section('content')

<h1>Página não encontrada</h1>

<img src="" alt="">

<h3><a href="{{ route('homepage') }}">Voltar para o Início</a></h3>

@endsection