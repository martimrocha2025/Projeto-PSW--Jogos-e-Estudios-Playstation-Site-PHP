@extends ('layout.fo')

@section('content')
<div class="text-center py-5">
    <h1 class="display-4 fw-bold mb-3">Estúdios Playstation</h1>
    <a href="{{ route('estudios.home') }}" class="btn btn-primary">Ver Estúdios</a>
    <a href ="{{ route('dashboard') }}" class="btn btn-primary ">Ver Dashboard</a>
</div>

@endsection