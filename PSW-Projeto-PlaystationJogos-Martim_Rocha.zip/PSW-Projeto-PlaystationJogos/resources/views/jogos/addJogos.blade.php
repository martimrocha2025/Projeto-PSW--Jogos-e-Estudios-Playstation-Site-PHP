@extends ('layout.fo')


@section('content')

@auth
@if (Auth::user()->user_type == \App\Models\User::USER_ADMIN)
    <h2>Adicionar Jogo</h2>

<form method="POST" action="{{ route('jogos.store') }}" enctype="multipart/form-data">
    @csrf
  <div class="mb-3">
    <label for="name" class="form-label">Nome</label>
    <input name="name" type="text" class="form-control" id="name" aria-describedby="nameHelp">
    <div id="nameHelp" class="form-text">Inserir o nome do Jogo.</div>
  </div>
  @error('name')
  <p> Nome inválido </p>
  @enderror
  <div class="mb-3">
    <label for="genre" class="form-label">Gênero</label>
    <input name="genre" type="text" class="form-control" id="genre" aria-describedby="genreHelp">
    <div id="genreHelp" class="form-text">Inserir o gênero do Jogo.</div>
  </div>
  @error('genre')
  <p> Input inválido </p>
  @enderror
  <div class="mb-3">
    <label for="data_lancamento" class="form-label">Data de Lançamento</label>
    <input name="data_lancamento" type="date" class="form-control" id="data_lancamento">
  </div>
  @error('data_lancamento')
  <p> Data inválida </p>
  @enderror
  <div class="mb-3">
    <label for="photo" class="form-label">Imagem do Jogo</label>
    <input type="file" accept="image/*" name="image" class="form-control" id="photo">
  </div>
  @error('image')
  <p> Imagem não suportada </p>
  @enderror
  <select required name="estudio_id" class="form-control">
        <option disabled value="">Selecione um estúdio</option>
        @foreach ($estudios as $estudio)
        <option value="{{ $estudio->id }}">
            {{ $estudio->name_estudio }}
        </option>
        @endforeach
    </select>
  <button type="submit" class="btn btn-primary">Adicionar Jogo</button>
</form>

@else
    <h2>Não tens permissão para aceder a esta página</h2>
@endif
@endauth

@endsection