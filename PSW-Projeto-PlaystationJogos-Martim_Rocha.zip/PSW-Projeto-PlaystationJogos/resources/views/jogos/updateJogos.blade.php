@extends('layout.fo')

@section('content')

@isset($jogo)
<form method="POST" action="{{ route('jogos.put', $jogo->id) }}" enctype="multipart/form-data">
    @method('PUT')
    @csrf
    <input type="hidden" value="{{ $jogo->id }}" name="id">
  <div class="mb-3">
    <label for="name" class="form-label">Nome</label>
    <input type="text" name="name" class="form-control" id="name" aria-describedby="stringHelp" value="{{$jogo->name}}">
    <div id="stringHelp" class="form-text">Inserir o nome do Jogo.</div>
  </div>
  <div class="mb-3">
    <label for="genre" class="form-label">Gênero</label>
    <input type="text" name="genre" class="form-control" id="genre" value="{{$jogo->genre}}">
    <div id="passwordHelp" class="form-text">Inserir o gênero do Jogo.</div>
  </div>
  <div class="mb-3">
    <label for="data_lancamento" class="form-label">Data de Lançamento</label>
    <input type="date" name="data_lancamento" class="form-control" id="data_lancamento" value="{{$jogo->date}}">
  </div>
  <div class="mb-3">
    <label for="image" class="form-label">Imagem do Jogo</label>
    <input type="file" accept="image/*" name="image" class="form-control" id="image">
  </div>
  <div class="dropdown">
    <select required name="estudio_id" class="form-control">
        <option disabled value="">Selecione um estúdio</option>
        @foreach ($estudios as $estudio)
            <option value="{{ $estudio->id }}" @selected($estudio->id == $jogo->estudio_id)>
                {{ $estudio->name_estudio }}
            </option>
        @endforeach
    </select>
</div>
  <button type="submit" class="btn btn-primary">Atualizar Jogo</button>
</form>
@endisset

@endsection