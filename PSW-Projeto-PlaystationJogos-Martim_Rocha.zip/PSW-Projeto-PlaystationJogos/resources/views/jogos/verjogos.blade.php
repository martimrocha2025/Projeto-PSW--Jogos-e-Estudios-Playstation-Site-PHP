@extends ('layout.fo')

@section('content')


<h2>Página de Jogos do Estúdio: </h2>

<table class="table table-primary">
<thead>
    <tr>
        <th></th>
        <th>Nome</th>
        <th>Gênero</th>
        <th>Data de Lançamento</th>
        <th></th>
    </tr>
</thead>  
<tbody>
    @foreach ($Jogos as $jogo)
    <tr>
<td><img width="40px" height= "40px" src="{{$jogo->image ? asset('storage/' . str_replace('public/', '', $jogo->image)) : asset('images/nophoto.jpg')}}" alt=""> </td>
<td>{{ $jogo->name }}</td>
<td>{{ $jogo->genre}}</td>
<td>{{ $jogo->date}}</td>
<td>@auth
    @if (Auth::user()->user_type == \App\Models\User::USER_ADMIN)
        <a href="{{ route('jogos.delete', $jogo->id) }}" class="btn btn-warning">Eliminar</a>
    @endif
        <a href="{{ route('jogos.update', $jogo->id) }}" class="btn btn-info">Editar</a>
    @endauth
</td>
</tr>
    @endforeach
  </tbody>
</table>


@auth
@if (Auth::user()->user_type == \App\Models\User::USER_ADMIN)
<a href="{{ route('jogos.add') }}" class="btn btn-primary">Adicionar Jogo</a>
@endif
@endauth

@endsection