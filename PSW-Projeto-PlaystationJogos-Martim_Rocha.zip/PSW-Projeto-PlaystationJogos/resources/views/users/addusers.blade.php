@extends('layout.fo')

@section('content')

<p2> Registar Novo user </p2>

<form method ="POST" action="{{route('users.store')}}" enctype="multipart/form-data">
        @csrf
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="email" name= "email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    <div id="emailHelp" class="form-text"></div>
  </div>
  @error('email')
  <p> Email não é válido </p>
  @enderror
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Name</label>
    <input type="name" name="name" class="form-control" id="exampleInputPassword1">
  </div>
  @error('name')
  <p> Nome não é válido </p>
  @enderror
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" name="password" class="form-control" id="exampleInputPassword1">
  </div>
  @error('password')
  <p> Password não é válido </p>
  @enderror
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

@endsection