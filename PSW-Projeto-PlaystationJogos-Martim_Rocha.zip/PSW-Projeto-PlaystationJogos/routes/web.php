<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EstudioController;
use App\Http\Controllers\JogosController;
use App\Http\Controllers\UtilController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;

Route::get('/',[UtilController::class, 'home'])->name('homepage');



//Estudios

Route::get('/update-estudio/{id}', [EstudioController::class, 'UpdateEstudio'])->name('estudios.update') -> middleware('auth');   
Route::get('/estudios', [EstudioController::class, 'Estudios'])->name('estudios.home');
Route::get('/add-estudio', [EstudioController::class, 'AddEstudio'])->name('estudios.add') ->middleware('auth'); //admin
Route::post('/store-estudio', [EstudioController::class, 'StoreEstudio'])->name('estudios.store') -> middleware('auth');
Route::put('/put-estudio/{id}', [EstudioController::class, 'PutEstudio'])->name('estudios.put') ->middleware('auth');
Route::get('/delete-estudio/{id}', [EstudioController::class, 'DeleteEstudio'])->name('estudios.delete')-> middleware('auth');
//

//Jogos

Route::get('/update-jogo/{id}', [JogosController::class, 'UpdateJogo'])->name('jogos.update')-> middleware('auth');
Route::get('/ver-jogos/{id}', [JogosController::class, 'VerJogos'])->name('jogos.verjogos');
Route::get('/add-jogo', [JogosController::class, 'AddJogo'])->name('jogos.add')-> middleware('auth'); 
Route::post('/store-jogo', [JogosController::class, 'StoreJogo'])->name('jogos.store')-> middleware('auth');
Route::put('/put-jogo/{id}', [JogosController::class, 'PutJogo'])->name('jogos.put')-> middleware('auth');
Route::get('/delete-jogo/{id}', [JogosController::class, 'DeleteJogo'])->name('jogos.delete')-> middleware('auth');
//

//Users
Route::get('/add-user', [AuthController::class, 'AddUser'])->name('users.add'); 
Route::post('/store-user', [AuthController::class, 'StoreUser'])->name('users.store'); 

//Dashboard

Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard')->middleware('auth');

//

//fallback

Route::fallback([UtilController::class, 'fallback']);

//