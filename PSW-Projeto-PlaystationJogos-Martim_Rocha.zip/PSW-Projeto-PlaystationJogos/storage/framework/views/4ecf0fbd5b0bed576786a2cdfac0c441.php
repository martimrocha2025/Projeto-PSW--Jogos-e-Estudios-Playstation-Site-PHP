<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Homepage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Jogos e Estúdios Playstation</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="<?php echo e(route('homepage')); ?>">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('estudios.home')); ?>">Estúdios</a>
                    </li>
                    <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->user_type == \App\Models\User::USER_ADMIN): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('estudios.add')); ?>">Adicionar Estúdios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('jogos.add')); ?>" aria-disabled="true">Adicionar Jogos</a>
                    </li>
                    <?php endif; ?>
                    <?php endif; ?>
                </ul>
            </div>
            <?php if(Route::has('login')): ?>
                <nav class="flex items-center justify-end gap-4">
                    <?php if(auth()->guard()->check()): ?>
                        <a
                            href="<?php echo e(url('/dashboard')); ?>"
                            class="btn btn-primary me-2"
                        >
                            Dashboard
                        </a>

                        <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-primary">Logout</button>
                        </form>
                    <?php else: ?>
                        <a
                            href="<?php echo e(route('login')); ?>"
                            class="btn btn-primary me-2"
                        >
                            Log in
                        </a>

                        <?php if(Route::has('register')): ?>
                            <a
                                href="<?php echo e(route('users.add')); ?>"
                                class="btn btn-primary">
                                Register
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </nav>
            <?php endif; ?>

        </div>
    </nav>
<div class="container">
<?php echo $__env->yieldContent('content'); ?>
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous">
    </script>
</body>

</html><?php /**PATH C:\Users\marti\PSW-Projeto-PlaystationJogos\resources\views/layout/fo.blade.php ENDPATH**/ ?>