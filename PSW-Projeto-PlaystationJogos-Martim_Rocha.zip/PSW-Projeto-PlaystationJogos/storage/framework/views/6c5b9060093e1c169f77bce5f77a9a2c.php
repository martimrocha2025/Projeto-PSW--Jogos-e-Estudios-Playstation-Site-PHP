

<?php $__env->startSection('content'); ?>

<h2> Estúdios Playstation </h2>
<table class="table table-primary">
<thead>
    <tr>
        <th>Logo</th>
        <th>Nome</th>
        <th></th>
    </tr>
</thead>  
<tbody>
    <?php $__currentLoopData = $estudioFromDB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
<td><img width="40px" height= "40px" src="<?php echo e($estudio->logo ? asset('storage/' . str_replace('public/', '', $estudio->logo)) : asset('images/nophoto.jpg')); ?>" alt=""> </td>
<td><?php echo e($estudio->name_estudio); ?></td>
<td><a href="<?php echo e(route('jogos.verjogos', ['id' => $estudio->id])); ?>" class="btn btn-info">Ver Jogos</a> 
<?php if(auth()->guard()->check()): ?>
<?php if(Auth::user()->user_type == \App\Models\User::USER_ADMIN): ?>    
<a href="<?php echo e(route('estudios.delete', $estudio->id)); ?>" class="btn btn-danger">Eliminar</a>
    <a href="<?php echo e(route('estudios.update', $estudio->id)); ?>" class="btn btn-warning">Editar</a>
<?php endif; ?>
<?php endif; ?>
</td>

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php if(auth()->guard()->check()): ?>
<?php if(Auth::user()->user_type == \App\Models\User::USER_ADMIN): ?>
<a href="<?php echo e(route('estudios.add')); ?>" class="btn btn-primary">Adicionar Estúdio</a>
<?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.fo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marti\PSW-Projeto-PlaystationJogos\resources\views/estudios/verEstudio.blade.php ENDPATH**/ ?>