

<?php $__env->startSection('content'); ?>

<h2>Dashboard</h2>
<p>Olá, <?php echo e(Auth::user()->name); ?></p>
<?php if(Auth::user()->user_type == \App\Models\User::USER_ADMIN): ?>
    <p>És Admin</p>
<?php else: ?>
    <p>És User</p>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.fo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marti\PSW-Projeto-PlaystationJogos\resources\views/dashboard/homeDashboard.blade.php ENDPATH**/ ?>