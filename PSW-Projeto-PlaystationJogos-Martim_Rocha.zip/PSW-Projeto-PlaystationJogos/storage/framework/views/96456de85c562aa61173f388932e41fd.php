

<?php $__env->startSection('content'); ?>

<?php if(isset($jogo)): ?>
<form method="POST" action="<?php echo e(route('jogos.put', $jogo->id)); ?>" enctype="multipart/form-data">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    <input type="hidden" value="<?php echo e($jogo->id); ?>" name="id">
  <div class="mb-3">
    <label for="name" class="form-label">Nome</label>
    <input type="text" name="name" class="form-control" id="name" aria-describedby="stringHelp" value="<?php echo e($jogo->name); ?>">
    <div id="stringHelp" class="form-text">Inserir o nome do Jogo.</div>
  </div>
  <div class="mb-3">
    <label for="genre" class="form-label">Gênero</label>
    <input type="text" name="genre" class="form-control" id="genre" value="<?php echo e($jogo->genre); ?>">
    <div id="passwordHelp" class="form-text">Inserir o gênero do Jogo.</div>
  </div>
  <div class="mb-3">
    <label for="data_lancamento" class="form-label">Data de Lançamento</label>
    <input type="date" name="data_lancamento" class="form-control" id="data_lancamento" value="<?php echo e($jogo->date); ?>">
  </div>
  <div class="mb-3">
    <label for="image" class="form-label">Imagem do Jogo</label>
    <input type="file" accept="image/*" name="image" class="form-control" id="image">
  </div>
  <div class="dropdown">
    <select required name="estudio_id" class="form-control">
        <option disabled value="">Selecione um estúdio</option>
        <?php $__currentLoopData = $estudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($estudio->id); ?>" <?php if($estudio->id == $jogo->estudio_id): echo 'selected'; endif; ?>>
                <?php echo e($estudio->name_estudio); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
  <button type="submit" class="btn btn-primary">Atualizar Jogo</button>
</form>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.fo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marti\PSW-Projeto-PlaystationJogos\resources\views/jogos/updateJogos.blade.php ENDPATH**/ ?>