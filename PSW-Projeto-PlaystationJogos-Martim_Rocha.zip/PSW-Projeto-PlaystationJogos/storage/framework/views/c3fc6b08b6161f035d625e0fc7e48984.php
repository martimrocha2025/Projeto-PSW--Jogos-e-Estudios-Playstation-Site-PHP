

<?php $__env->startSection('content'); ?>
<div class="text-center py-5">
    <h1 class="display-4 fw-bold mb-3">Estúdios Playstation</h1>
    <a href="<?php echo e(route('estudios.home')); ?>" class="btn btn-primary">Ver Estúdios</a>
    <a href ="<?php echo e(route('dashboard')); ?>" class="btn btn-primary ">Ver Dashboard</a>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.fo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marti\PSW-Projeto-PlaystationJogos\resources\views/homepage.blade.php ENDPATH**/ ?>