


<?php $__env->startSection('content'); ?>

<?php if(auth()->guard()->check()): ?>
<?php if(Auth::user()->user_type == \App\Models\User::USER_ADMIN): ?>
<?php if(isset($estudio)): ?>
<h2>Editar Estúdio</h2>
<form method="POST" action="<?php echo e(route('estudios.put', $estudio->id)); ?>" enctype="multipart/form-data">
<?php echo method_field('PUT'); ?>    
<?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="name_estudio" class="form-label">Nome</label>
    <input type="text" name="name_estudio" value="<?php echo e(old('name_estudio', $estudio->name_estudio)); ?>" class="form-control" id="name_estudio" aria-describedby="nameHelp">
    <div id="nameHelp" class="form-text">Inserir o nome do estúdio.</div>
  </div>
  <?php $__errorArgs = ['name_estudio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <p> Nome inválido </p>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  <div class="mb-3">
    <label for="logo" class="form-label">Logo do Estúdio</label>
    <input type="file" accept="image/*" name="logo" class="form-control" id="logo">
  </div>
  <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<p> Imagem não suportada </p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  <button type="submit" class="btn btn-primary">Atualizar Estúdio</button>
</form>

<?php else: ?>
    <h2>Não tens permissão para aceder a esta página</h2>
<?php endif; ?>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.fo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marti\PSW-Projeto-PlaystationJogos\resources\views/estudios/updateEstudio.blade.php ENDPATH**/ ?>