


<?php $__env->startSection('content'); ?>

<h1>Página não encontrada</h1>

<img src="" alt="">

<h3><a href="<?php echo e(route('homepage')); ?>">Voltar para o Início</a></h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.fo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marti\PSW-Projeto-PlaystationJogos\resources\views/fallback.blade.php ENDPATH**/ ?>