

<?php $__env->startSection('content'); ?>


<h2>Página de Jogos do Estúdio: </h2>

<table class="table table-primary">
<thead>
    <tr>
        <th></th>
        <th>Nome</th>
        <th>Gênero</th>
        <th>Data de Lançamento</th>
        <th></th>
    </tr>
</thead>  
<tbody>
    <?php $__currentLoopData = $Jogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jogo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
<td><img width="40px" height= "40px" src="<?php echo e($jogo->image ? asset('storage/' . str_replace('public/', '', $jogo->image)) : asset('images/nophoto.jpg')); ?>" alt=""> </td>
<td><?php echo e($jogo->name); ?></td>
<td><?php echo e($jogo->genre); ?></td>
<td><?php echo e($jogo->date); ?></td>
<td><?php if(auth()->guard()->check()): ?>
    <?php if(Auth::user()->user_type == \App\Models\User::USER_ADMIN): ?>
        <a href="<?php echo e(route('jogos.delete', $jogo->id)); ?>" class="btn btn-warning">Eliminar</a>
    <?php endif; ?>
        <a href="<?php echo e(route('jogos.update', $jogo->id)); ?>" class="btn btn-info">Editar</a>
    <?php endif; ?>
</td>
</tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>


<?php if(auth()->guard()->check()): ?>
<?php if(Auth::user()->user_type == \App\Models\User::USER_ADMIN): ?>
<a href="<?php echo e(route('jogos.add')); ?>" class="btn btn-primary">Adicionar Jogo</a>
<?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.fo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marti\PSW-Projeto-PlaystationJogos\resources\views/jogos/verjogos.blade.php ENDPATH**/ ?>